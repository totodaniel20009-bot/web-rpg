// 이름 입력 → 게임 시작
import { GameScene } from "./GameScene.js";

const form = document.getElementById("login");
const nameInput = document.getElementById("name");

try {
  nameInput.value = localStorage.getItem("playerName") || "";
} catch {
  /* 저장소를 못 쓰는 환경이면 무시 */
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const name = nameInput.value.trim() || "모험가";
  try {
    localStorage.setItem("playerName", name);
  } catch {
    /* 무시 */
  }
  form.hidden = true;
  nameInput.blur();

  const game = new Phaser.Game({
    type: Phaser.AUTO,
    parent: "game",
    backgroundColor: "#14161c",
    scale: {
      mode: Phaser.Scale.RESIZE,
      width: window.innerWidth,
      height: window.innerHeight,
    },
  });
  game.scene.add("game", GameScene, true, { name });
});
