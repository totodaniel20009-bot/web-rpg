// 게임 화면 (Phaser). 쿼터뷰 맵을 그리고, 입력을 서버에 보내고, 서버가 알려주는 플레이어들을 보여준다.
//
// 화면 좌표 규칙: 월드 (x, y, z) → 화면 (x, y - z). 높이(z)가 올라가면 화면에서 위로 올라간다.
// 그리는 순서(depth): 캐릭터는 y + z, 블록은 (아랫면 y - 8) 로 정해서 앞쪽이 뒤쪽을 가린다.

import { TILE, MAP_W, MAP_H, WORLD_W, WORLD_H, MAP_ROWS, SPAWN, VISUAL_HEIGHT } from "/shared/map.js";
import { createPlayer, stepPlayer, groundHeightAt, SIM_DT } from "/shared/physics.js";

const BLOCK_COLORS = {
  "#": { top: 0x8b91a3, front: 0x5b6173 }, // 벽
  "2": { top: 0xd2ad6e, front: 0xa07f4a }, // 낮은 블록
  "3": { top: 0x9cc7dc, front: 0x6c97ad }, // 높은 블록
};
const LABEL_FONT = "system-ui, 'Malgun Gothic', 'Noto Sans KR', sans-serif";

// 접속 ID 로 캐릭터 색(색상 12가지 중 하나)을 정한다
function hueFor(id) {
  let h = 0;
  for (const ch of id) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return (h % 12) * 30;
}

export class GameScene extends Phaser.Scene {
  constructor() {
    super("game");
  }

  init(data) {
    this.playerName = data.name || "모험가";
  }

  create() {
    this.hud = document.getElementById("hud");
    this.hud.hidden = false;
    this.lastHud = "";
    this.status = "서버에 접속하는 중...";
    this.playerCount = 0;

    this.room = null;
    this.roster = {}; // sessionId -> 이름
    this.others = new Map(); // sessionId -> 다른 플레이어 화면 객체
    this.me = null; // 내 캐릭터의 로컬 예측 상태 (서버와 같은 물리 코드로 계산)
    this.meView = null;
    this.acc = 0;
    this.idleTime = 0;
    this.curInput = { mx: 0, my: 0, jump: false };
    this.sentInput = null;

    this.makeBaseTextures();
    this.drawWorld();

    this.keys = this.input.keyboard.addKeys("W,A,S,D,UP,DOWN,LEFT,RIGHT,SPACE");

    // 카메라는 캐릭터의 "바닥 위치"를 따라간다 (점프할 때 화면이 출렁이지 않게)
    this.camTarget = this.add.rectangle(SPAWN.x, SPAWN.y, 2, 2, 0x000000, 0);
    const cam = this.cameras.main;
    cam.setBounds(0, -96, WORLD_W, WORLD_H + 96);
    cam.startFollow(this.camTarget, true, 0.12, 0.12);
    this.scale.on("resize", this.onResize, this);
    this.onResize();

    // 창을 벗어나 키 입력이 끊기면 멈춘 것으로 처리
    this.game.events.on(Phaser.Core.Events.BLUR, this.releaseInput, this);

    this.connect();
  }

  onResize() {
    const zoom = Phaser.Math.Clamp(this.scale.height / 380, 1.2, 3);
    this.cameras.main.setZoom(zoom);
  }

  // ── 접속 ───────────────────────────────────────────
  async connect() {
    try {
      const proto = location.protocol === "https:" ? "wss" : "ws";
      const client = new Colyseus.Client(`${proto}://${location.host}`);
      const room = await client.joinOrCreate("world", { name: this.playerName });
      this.room = room;

      room.onMessage("roster", (roster) => {
        this.roster = roster;
      });
      room.onMessage("snap", (msg) => this.onSnapshot(msg));
      room.onLeave((code) => {
        this.room = null;
        this.status = `연결이 끊겼어요 (code ${code}). 새로고침하면 다시 접속해요.`;
      });
      room.onError((code, message) => {
        this.status = `오류가 났어요: ${message ?? code}`;
      });
      this.status = "";
    } catch (err) {
      console.error(err);
      this.status = `서버에 접속하지 못했어요: ${err?.message ?? err}`;
    }
  }

  // 서버가 보내준 모든 플레이어의 현재 상태 (초당 30번)
  onSnapshot(msg) {
    const seen = new Set();
    for (const [id, x, y, z, dir] of msg.p) {
      seen.add(id);
      if (id === this.room?.sessionId) {
        this.onOwnState(x, y, z, dir);
        continue;
      }
      let v = this.others.get(id);
      if (!v) {
        v = this.createView(id, false);
        v.x = v.tx = x;
        v.y = v.ty = y;
        v.z = v.tz = z;
        this.others.set(id, v);
      }
      v.tx = x;
      v.ty = y;
      v.tz = z;
      v.dir = dir;
    }
    for (const [id, v] of this.others) {
      if (!seen.has(id)) {
        v.shadow.destroy();
        v.body.destroy();
        v.label.destroy();
        this.others.delete(id);
      }
    }
    this.playerCount = msg.p.length;
  }

  // 내 캐릭터는 로컬에서 바로 움직이고(반응이 빠르게), 서버 값과 많이 어긋나면 서버 쪽으로 맞춘다
  onOwnState(x, y, z, dir) {
    if (!this.me) {
      this.me = createPlayer(x, y);
      this.me.z = z;
      this.me.dir = dir;
      this.meView = this.createView(this.room.sessionId, true);
      return;
    }
    const me = this.me;
    const dx = x - me.x;
    const dy = y - me.y;
    const err = Math.hypot(dx, dy);
    const moving = this.curInput.mx !== 0 || this.curInput.my !== 0;
    const limit = moving ? 90 : 40; // 움직이는 동안은 네트워크 지연만큼 서버가 뒤처져 보이는 게 정상

    if (err > limit || Math.abs(z - me.z) > 40) {
      me.x = x;
      me.y = y;
      me.z = z;
      me.vz = 0;
      me.grounded = z <= groundHeightAt(x, y) + 0.01;
    } else if (this.idleTime > 0.5 && me.grounded && err > 0.3) {
      me.x += dx * 0.25; // 가만히 있을 때만 서서히 서버 위치로 보정
      me.y += dy * 0.25;
    }
  }

  // ── 입력 ───────────────────────────────────────────
  readInput() {
    const k = this.keys;
    const mx = (k.D.isDown || k.RIGHT.isDown ? 1 : 0) - (k.A.isDown || k.LEFT.isDown ? 1 : 0);
    const my = (k.S.isDown || k.DOWN.isDown ? 1 : 0) - (k.W.isDown || k.UP.isDown ? 1 : 0);
    return { mx, my, jump: k.SPACE.isDown };
  }

  sendInputIfChanged(input) {
    const s = this.sentInput;
    if (s && s.mx === input.mx && s.my === input.my && s.jump === input.jump) return;
    this.sentInput = input;
    try {
      this.room?.send("input", input);
    } catch (err) {
      console.error(err);
    }
  }

  releaseInput() {
    this.curInput = { mx: 0, my: 0, jump: false };
    this.sendInputIfChanged(this.curInput);
  }

  // ── 매 프레임 ──────────────────────────────────────
  update(time, delta) {
    const dt = Math.min(delta, 100) / 1000;
    this.updateHud();
    if (!this.room || !this.me) return;

    const input = this.readInput();
    this.curInput = input;
    this.sendInputIfChanged(input);

    // 서버와 같은 고정 간격(1/60초)으로 내 캐릭터를 진행
    this.acc += dt;
    while (this.acc >= SIM_DT) {
      stepPlayer(this.me, input, SIM_DT);
      this.acc -= SIM_DT;
    }
    const still = input.mx === 0 && input.my === 0 && this.me.grounded;
    this.idleTime = still ? this.idleTime + dt : 0;

    this.renderView(this.meView, this.me.x, this.me.y, this.me.z, this.me.vz);
    this.camTarget.setPosition(this.me.x, this.me.y - 14);

    // 다른 플레이어는 서버가 알려준 위치로 부드럽게 따라간다
    const k = 1 - Math.exp(-18 * dt);
    for (const v of this.others.values()) {
      v.x += (v.tx - v.x) * k;
      v.y += (v.ty - v.y) * k;
      v.z += (v.tz - v.z) * k;
      this.renderView(v, v.x, v.y, v.z, 0);
    }
  }

  updateHud() {
    let text;
    if (this.status) {
      text = this.status;
    } else {
      const lines = [`접속자 ${this.playerCount}명`];
      if (this.me) {
        lines.push(`위치 x:${Math.round(this.me.x)} y:${Math.round(this.me.y)} 높이:${Math.round(this.me.z)}`);
      }
      lines.push("이동 WASD/방향키 · 점프 Space");
      text = lines.join("\n");
    }
    if (text !== this.lastHud) {
      this.hud.textContent = text;
      this.lastHud = text;
    }
  }

  // ── 그리기 ─────────────────────────────────────────
  makeBaseTextures() {
    const g = this.make.graphics({ add: false });
    g.fillStyle(0x000000, 0.55);
    g.fillEllipse(13, 6, 26, 12);
    g.generateTexture("shadow", 26, 12);
    g.destroy();
  }

  playerTexture(hue) {
    const key = `player-${hue}`;
    if (this.textures.exists(key)) return key;
    const body = Phaser.Display.Color.HSLToColor(hue / 360, 0.65, 0.5).color;
    const dark = Phaser.Display.Color.HSLToColor(hue / 360, 0.65, 0.32).color;
    const g = this.make.graphics({ add: false });
    g.fillStyle(dark, 1);
    g.fillRoundedRect(4, 15, 16, 19, 5); // 몸 (테두리색)
    g.fillStyle(body, 1);
    g.fillRoundedRect(5, 15, 14, 17, 5); // 몸
    g.fillStyle(0x2a2a33, 1);
    g.fillRect(6, 31, 5, 3); // 발
    g.fillRect(13, 31, 5, 3);
    g.fillStyle(0xf3d6b6, 1);
    g.fillCircle(12, 10, 8); // 얼굴
    g.fillStyle(dark, 1);
    g.fillRoundedRect(4, 1, 16, 7, { tl: 7, tr: 7, bl: 0, br: 0 }); // 머리카락
    g.fillStyle(0x222222, 1);
    g.fillRect(8, 10, 2, 3); // 눈
    g.fillRect(14, 10, 2, 3);
    g.generateTexture(key, 24, 34);
    g.destroy();
    return key;
  }

  drawWorld() {
    // 바닥: 체크무늬 잔디
    const floor = this.add.graphics().setDepth(-100000);
    for (let ty = 0; ty < MAP_H; ty++) {
      for (let tx = 0; tx < MAP_W; tx++) {
        floor.fillStyle((tx + ty) % 2 ? 0x3d7a49 : 0x387345, 1);
        floor.fillRect(tx * TILE, ty * TILE, TILE, TILE);
      }
    }
    // 블록/벽: 윗면 + 앞면을 그려서 입체감을 낸다
    for (let ty = 0; ty < MAP_H; ty++) {
      for (let tx = 0; tx < MAP_W; tx++) {
        const ch = MAP_ROWS[ty][tx];
        const vh = VISUAL_HEIGHT[ch];
        if (!vh) continue;
        const c = BLOCK_COLORS[ch];
        const x0 = tx * TILE;
        const topY = ty * TILE - vh;
        const g = this.add.graphics().setDepth((ty + 1) * TILE - 8);
        g.fillStyle(c.front, 1);
        g.fillRect(x0, topY + TILE, TILE, vh);
        g.fillStyle(c.top, 1);
        g.fillRect(x0, topY, TILE, TILE);
        g.lineStyle(1, 0x000000, 0.18);
        g.strokeRect(x0 + 0.5, topY + 0.5, TILE - 1, TILE - 1);
        g.strokeRect(x0 + 0.5, topY + TILE + 0.5, TILE - 1, vh - 1);
      }
    }
  }

  createView(id, isMe) {
    const shadow = this.add.image(0, 0, "shadow").setOrigin(0.5);
    const body = this.add.image(0, 0, this.playerTexture(hueFor(id))).setOrigin(0.5, 1);
    const label = this.add
      .text(0, 0, "", {
        fontFamily: LABEL_FONT,
        fontSize: "12px",
        color: isMe ? "#ffe08a" : "#ffffff",
        stroke: "#000000",
        strokeThickness: 3,
      })
      .setOrigin(0.5, 1)
      .setResolution(3)
      .setDepth(1e6);
    return { id, isMe, shadow, body, label, x: 0, y: 0, z: 0, tx: 0, ty: 0, tz: 0, dir: 0 };
  }

  // 한 캐릭터를 월드 좌표 (x, y, z) 에 맞춰 화면에 배치한다
  renderView(v, x, y, z, vz) {
    const gz = groundHeightAt(x, y); // 발 밑 바닥(또는 블록 윗면) 높이
    const air = Math.max(0, z - gz);
    const s = Phaser.Math.Clamp(1 - air / 170, 0.45, 1); // 높이 뜰수록 그림자가 작고 흐려짐

    v.shadow.setPosition(x, y - gz).setScale(s).setAlpha(s).setDepth(y + gz - 1);

    const stretch = 1 + (Math.min(Math.abs(vz), 450) / 450) * 0.1; // 점프 중 살짝 길쭉하게
    v.body.setPosition(x, y - z).setScale(2 - stretch, stretch).setDepth(y + z);

    v.label.setPosition(x, y - z - 38);
    const name = this.roster[v.id];
    if (name && v.label.text !== name) v.label.setText(name);
  }
}
