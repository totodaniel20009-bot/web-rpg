// 게임 월드 방. 서버가 모든 이동/점프를 직접 계산한다 (클라이언트는 "입력"만 보낸다).
import { Room } from "colyseus";
import { createPlayer, stepPlayer, collides, SIM_DT } from "../shared/physics.js";
import { SPAWN } from "../shared/map.js";

const SNAPSHOT_EVERY = 2; // 시뮬레이션 2스텝(60Hz)마다 1번 → 초당 30번 상태 전송
const MAX_STEPS_PER_UPDATE = 5; // 서버가 잠깐 밀려도 한 번에 너무 많이 계산하지 않음
const round1 = (v) => Math.round(v * 10) / 10;

function cleanName(raw) {
  const name = String(raw ?? "")
    .replace(/[\u0000-\u001f\u007f]/g, "")
    .trim()
    .slice(0, 12);
  return name || "모험가";
}

export class WorldRoom extends Room {
  maxClients = 50;

  onCreate() {
    this.players = new Map(); // sessionId -> { name, body, input }
    this.acc = 0;
    this.stepCount = 0;

    // 클라이언트가 보내는 건 "지금 어느 방향 키를 누르고 있나, 점프 키를 누르고 있나" 뿐이다.
    this.onMessage("input", (client, msg) => {
      const player = this.players.get(client.sessionId);
      if (!player || !msg || typeof msg !== "object") return;
      const clamp1 = (v) => {
        const n = Number(v);
        return Number.isFinite(n) ? Math.max(-1, Math.min(1, n)) : 0;
      };
      player.input.mx = clamp1(msg.mx);
      player.input.my = clamp1(msg.my);
      player.input.jump = msg.jump === true;
    });

    // 고정 간격(60Hz)으로 월드를 진행시킨다
    this.setSimulationInterval((deltaMs) => this.update(deltaMs), 1000 / 60);
  }

  onJoin(client, options) {
    // 시작 위치 근처에서 겹치지 않는 자리를 찾는다
    let x = SPAWN.x;
    let y = SPAWN.y;
    for (let i = 0; i < 10; i++) {
      const tx = SPAWN.x + (Math.random() - 0.5) * 64;
      const ty = SPAWN.y + (Math.random() - 0.5) * 64;
      if (!collides(tx, ty, 0)) {
        x = tx;
        y = ty;
        break;
      }
    }
    this.players.set(client.sessionId, {
      name: cleanName(options?.name),
      body: createPlayer(x, y),
      input: { mx: 0, my: 0, jump: false },
    });
    this.broadcastRoster();
  }

  onLeave(client) {
    this.players.delete(client.sessionId);
    this.broadcastRoster();
  }

  // 누가 접속해 있고 이름이 뭔지 (자주 안 바뀌니까 변할 때만 보낸다)
  broadcastRoster() {
    const roster = {};
    for (const [id, p] of this.players) roster[id] = p.name;
    this.broadcast("roster", roster);
  }

  update(deltaMs) {
    this.acc += Math.min(deltaMs, 250) / 1000;
    let steps = 0;
    while (this.acc >= SIM_DT && steps < MAX_STEPS_PER_UPDATE) {
      for (const p of this.players.values()) stepPlayer(p.body, p.input, SIM_DT);
      this.acc -= SIM_DT;
      steps++;
      this.stepCount++;
      if (this.stepCount % SNAPSHOT_EVERY === 0) this.sendSnapshot();
    }
    if (steps === MAX_STEPS_PER_UPDATE) this.acc = 0; // 너무 밀렸으면 따라잡기를 포기
  }

  // 모든 플레이어의 현재 상태를 [id, x, y, z, 방향] 배열로 보낸다
  sendSnapshot() {
    if (this.players.size === 0) return;
    const list = [];
    for (const [id, p] of this.players) {
      const b = p.body;
      list.push([id, round1(b.x), round1(b.y), round1(b.z), round1(b.dir)]);
    }
    this.broadcast("snap", { p: list });
  }
}
