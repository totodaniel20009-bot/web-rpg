// 서버 진입점: 웹 페이지 파일 서빙 + Colyseus 실시간 게임 서버를 한 포트에서 같이 돌린다.
import http from "node:http";
import path from "node:path";
import { fileURLToPath } from "node:url";
import express from "express";
import { Server } from "colyseus";
import { WebSocketTransport } from "@colyseus/ws-transport";
import { WorldRoom } from "./WorldRoom.js";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const PORT = Number(process.env.PORT) || 2567;

const app = express();
// 브라우저에서 쓸 라이브러리 (npm 으로 설치된 것을 그대로 내려준다)
app.use("/vendor/phaser", express.static(path.join(root, "node_modules/phaser/dist")));
app.use("/vendor/colyseus", express.static(path.join(root, "node_modules/colyseus.js/dist")));
// 서버와 브라우저가 같이 쓰는 규칙(맵, 물리)
app.use("/shared", express.static(path.join(root, "shared")));
// 게임 화면
app.use(express.static(path.join(root, "client")));

const httpServer = http.createServer(app);
const gameServer = new Server({
  transport: new WebSocketTransport({ server: httpServer }),
});

// "world" 방 하나에 모두 접속한다. (나중에 맵마다 방을 나눌 수 있다)
gameServer.define("world", WorldRoom);

gameServer.listen(PORT).then(() => {
  console.log(`게임 서버 실행 중: http://localhost:${PORT}`);
  console.log("브라우저 탭을 두 개 열어서 서로 보이는지 확인해보세요.");
});
