// 물리/맵 테스트 — 의존성 없이 node 만으로 돌아간다.  실행: npm test
import assert from "node:assert/strict";
import { TILE, MAP_W, MAP_H, WORLD_W, WORLD_H, MAP_ROWS, MAP_ASCII, SPAWN, tileAt } from "../shared/map.js";
import {
  createPlayer, stepPlayer, collides, groundHeightAt,
  SIM_DT, PLAYER_RADIUS, JUMP_VELOCITY, GRAVITY,
} from "../shared/physics.js";

if (process.argv.includes("--map")) {
  console.log(MAP_ASCII);
  process.exit(0);
}

let passed = 0;
let failed = 0;
function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (e) {
    failed++;
    console.log(`  ✗ ${name}`);
    console.log(String(e.message).split("\n").map((l) => "      " + l).join("\n"));
  }
}

const center = (tx, ty) => ({ x: (tx + 0.5) * TILE, y: (ty + 0.5) * TILE });
const at = (tx, ty) => { const c = center(tx, ty); return createPlayer(c.x, c.y); };
// input 을 seconds 초 동안 적용
function run(p, input, seconds) {
  const n = Math.round(seconds / SIM_DT);
  for (let i = 0; i < n; i++) stepPlayer(p, input, SIM_DT);
  return p;
}
const IDLE = { mx: 0, my: 0, jump: false };

console.log("맵");
test("크기가 선언과 같고 가장자리가 전부 벽", () => {
  assert.equal(MAP_ROWS.length, MAP_H);
  for (const row of MAP_ROWS) assert.equal(row.length, MAP_W);
  for (let x = 0; x < MAP_W; x++) {
    assert.equal(tileAt(x, 0), "#");
    assert.equal(tileAt(x, MAP_H - 1), "#");
  }
  for (let y = 0; y < MAP_H; y++) {
    assert.equal(tileAt(0, y), "#");
    assert.equal(tileAt(MAP_W - 1, y), "#");
  }
});
test("시작 위치가 바닥이고 막히지 않음", () => {
  assert.equal(tileAt(Math.floor(SPAWN.x / TILE), Math.floor(SPAWN.y / TILE)), ".");
  assert.equal(collides(SPAWN.x, SPAWN.y, 0), false);
});
test("지형 높이 조회", () => {
  const c2 = center(5, 3);   // 낮은 블록
  const c3 = center(26, 3);  // 높은 블록
  assert.equal(groundHeightAt(c2.x, c2.y), 32);
  assert.equal(groundHeightAt(c3.x, c3.y), 64);
  assert.equal(groundHeightAt(SPAWN.x, SPAWN.y), 0);
});

console.log("이동");
test("가만히 있으면 안 움직이고, 오른쪽 입력이면 오른쪽으로 감", () => {
  const p = createPlayer(SPAWN.x, SPAWN.y);
  run(p, IDLE, 1);
  assert.equal(p.x, SPAWN.x);
  run(p, { mx: 1, my: 0, jump: false }, 0.2);
  assert.ok(Math.abs(p.x - (SPAWN.x + 30)) < 0.5, `x=${p.x}`); // 150 × 0.2
});
test("대각선 이동도 속도가 같다 (정규화)", () => {
  const p = createPlayer(SPAWN.x, SPAWN.y);
  run(p, { mx: 1, my: 1, jump: false }, 0.5);
  const dist = Math.hypot(p.x - SPAWN.x, p.y - SPAWN.y);
  assert.ok(Math.abs(dist - 75) < 1, `dist=${dist}`);
});
test("맵 밖으로 나갈 수 없다", () => {
  for (const [mx, my] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
    const p = createPlayer(SPAWN.x, SPAWN.y);
    run(p, { mx, my, jump: true }, 12);
    assert.ok(p.x > TILE && p.x < WORLD_W - TILE, `x=${p.x}`);
    assert.ok(p.y > TILE && p.y < WORLD_H - TILE, `y=${p.y}`);
  }
});

console.log("점프");
test("최고 높이와 체공 시간이 설계값과 비슷함", () => {
  const p = createPlayer(SPAWN.x, SPAWN.y);
  stepPlayer(p, { ...IDLE, jump: true }, SIM_DT);
  let peak = p.z, t = SIM_DT;
  while (!p.grounded && t < 3) {
    stepPlayer(p, IDLE, SIM_DT);
    peak = Math.max(peak, p.z);
    t += SIM_DT;
  }
  const ideal = (JUMP_VELOCITY ** 2) / (2 * GRAVITY);
  assert.ok(Math.abs(peak - ideal) < 5, `peak=${peak.toFixed(1)} ideal=${ideal.toFixed(1)}`);
  assert.ok(t > 0.75 && t < 0.9, `airtime=${t.toFixed(2)}s`);
  assert.equal(p.z, 0);
});
test("점프 키를 계속 눌러도 한 번만 뛴다 (공중 점프/자동 연속 점프 없음)", () => {
  const p = createPlayer(SPAWN.x, SPAWN.y);
  let takeoffs = 0, wasGrounded = true;
  for (let i = 0; i < 180; i++) {
    stepPlayer(p, { ...IDLE, jump: true }, SIM_DT);
    if (wasGrounded && !p.grounded) takeoffs++;
    wasGrounded = p.grounded;
  }
  assert.equal(takeoffs, 1);
});
test("키를 뗐다 다시 누르면 또 뛸 수 있다", () => {
  const p = createPlayer(SPAWN.x, SPAWN.y);
  stepPlayer(p, { ...IDLE, jump: true }, SIM_DT);
  run(p, IDLE, 1);
  assert.ok(p.grounded);
  stepPlayer(p, { ...IDLE, jump: true }, SIM_DT);
  assert.equal(p.grounded, false);
});

console.log("지형");
test("벽은 점프해도 넘을 수 없다", () => {
  const p = at(8, 8); // 오른쪽에 x=9 세로 벽
  for (let i = 0; i < 12; i++) {
    run(p, { mx: 1, my: 0, jump: true }, 0.25);
    run(p, { mx: 1, my: 0, jump: false }, 0.25);
  }
  assert.ok(p.x <= 9 * TILE - PLAYER_RADIUS + 0.01, `x=${p.x}`);
  assert.notEqual(tileAt(Math.floor(p.x / TILE), Math.floor(p.y / TILE)), "#");
});
test("낮은 블록(32): 걸어서는 못 오르고, 점프하면 위에 올라선다", () => {
  const walk = at(5, 5); // 블록 (x4~6, y3~4) 바로 아래
  run(walk, { mx: 0, my: -1, jump: false }, 2);
  assert.ok(walk.y >= 5 * TILE + PLAYER_RADIUS - 0.01, `walk.y=${walk.y}`);
  assert.equal(walk.z, 0);

  const p = at(5, 5);
  stepPlayer(p, { mx: 0, my: -1, jump: true }, SIM_DT);
  run(p, { mx: 0, my: -1, jump: false }, 0.25);
  run(p, IDLE, 1);
  assert.ok(p.grounded);
  assert.equal(p.z, 32);
  assert.ok(p.y < 5 * TILE && p.y > 3 * TILE, `y=${p.y}`);
});
test("높은 블록(64): 걸어서는 못 오르고, 점프하면 위에 올라선다", () => {
  const walk = at(26, 5); // 블록 (x26~27, y3~4) 바로 아래
  run(walk, { mx: 0, my: -1, jump: false }, 2);
  assert.ok(walk.y >= 5 * TILE + PLAYER_RADIUS - 0.01, `walk.y=${walk.y}`);

  const p = at(26, 5);
  stepPlayer(p, { mx: 0, my: -1, jump: true }, SIM_DT);
  run(p, { mx: 0, my: -1, jump: false }, 0.35);
  run(p, IDLE, 1);
  assert.ok(p.grounded);
  assert.equal(p.z, 64);
});
test("계단: 바닥 → 낮은 블록 → 높은 블록 순서로 올라갈 수 있다", () => {
  // 낮은 블록 (x12~13, y14~15), 오른쪽에 높은 블록 (x14~15, y14~15)
  const p = at(11, 15);
  stepPlayer(p, { mx: 1, my: 0, jump: true }, SIM_DT);
  run(p, { mx: 1, my: 0, jump: false }, 0.2);
  run(p, IDLE, 1);
  assert.equal(p.z, 32, `1단 z=${p.z}`);
  const x1 = p.x;
  // 낮은 블록 위(x≈396)에서 높은 블록 가장자리(x≈439)까지 가려면 약 0.3초 걸으므로 0.5초 이동
  stepPlayer(p, { mx: 1, my: 0, jump: true }, SIM_DT);
  run(p, { mx: 1, my: 0, jump: false }, 0.5);
  run(p, IDLE, 1);
  assert.equal(p.z, 64, `2단 z=${p.z}`);
  assert.ok(p.x > x1);
});
test("블록 가장자리를 벗어나면 떨어져서 바닥에 내려온다", () => {
  const p = at(5, 5);
  stepPlayer(p, { mx: 0, my: -1, jump: true }, SIM_DT);
  run(p, { mx: 0, my: -1, jump: false }, 0.25);
  run(p, IDLE, 1);
  assert.equal(p.z, 32);
  run(p, { mx: 0, my: 1, jump: false }, 1); // 아래(바닥 쪽)로 걸어 나감
  run(p, IDLE, 1);
  assert.equal(p.z, 0);
  assert.ok(p.grounded);
  assert.equal(collides(p.x, p.y, p.z), false);
});
test("블록 모서리에 겹쳐서 착지해도 끼이지 않고 다시 움직일 수 있다", () => {
  const p = at(5, 5);
  p.y = 5 * TILE + 3; // 블록 아랫면(y=160)에서 3만큼 떨어진 곳
  p.z = 45; p.grounded = false; p.vz = 0; // 블록 위(32)보다 높은 곳에서 낙하
  run(p, IDLE, 1);
  assert.equal(p.z, 0);
  assert.equal(collides(p.x, p.y, p.z), false);
  const before = p.x;
  run(p, { mx: 1, my: 0, jump: false }, 0.3);
  assert.ok(p.x > before + 30, `x ${before} → ${p.x}`);
});

console.log("서버/클라이언트 일관성");
test("같은 입력이면 항상 같은 결과 (예측이 서버와 어긋나지 않는 전제)", () => {
  const seq = [];
  for (let i = 0; i < 600; i++) {
    seq.push({ mx: Math.round(Math.sin(i / 40)), my: Math.round(Math.cos(i / 55)), jump: i % 97 < 3 });
  }
  const a = createPlayer(SPAWN.x, SPAWN.y);
  const b = createPlayer(SPAWN.x, SPAWN.y);
  for (const input of seq) {
    stepPlayer(a, input, SIM_DT);
    stepPlayer(b, input, SIM_DT);
  }
  assert.deepEqual(a, b);
});

console.log(`\n${passed} 통과, ${failed} 실패`);
if (failed > 0) process.exit(1);
