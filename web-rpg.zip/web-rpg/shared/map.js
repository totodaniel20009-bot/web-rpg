// 맵 정의 — 서버와 브라우저가 같은 파일을 import 해서 쓴다.
// 맵을 바꾸고 싶으면 아래 rect(...) 줄만 고치면 된다.

export const TILE = 32; // 타일 한 칸 크기 (월드 단위)
export const MAP_W = 32; // 가로 타일 수
export const MAP_H = 24; // 세로 타일 수
export const WORLD_W = MAP_W * TILE;
export const WORLD_H = MAP_H * TILE;

// 타일 종류
//   "."  바닥
//   "2"  낮은 블록  (높이 32, 점프로 올라갈 수 있음)
//   "3"  높은 블록  (높이 64, 점프로 올라갈 수 있음)
//   "#"  벽        (넘을 수 없음)
export const TILE_HEIGHT = { ".": 0, "2": 32, "3": 64, "#": 999 }; // 충돌 판정용 높이
export const VISUAL_HEIGHT = { ".": 0, "2": 32, "3": 64, "#": 96 }; // 화면에 그려지는 높이

const grid = Array.from({ length: MAP_H }, () => Array(MAP_W).fill("."));

// (x, y) 타일부터 가로 w칸, 세로 h칸을 ch 로 채운다
function rect(ch, x, y, w, h) {
  for (let j = y; j < y + h; j++) {
    for (let i = x; i < x + w; i++) {
      if (i >= 0 && i < MAP_W && j >= 0 && j < MAP_H) grid[j][i] = ch;
    }
  }
}

// ── 맵 배치 ──────────────────────────────────────────
rect("#", 0, 0, MAP_W, 1); // 위쪽 테두리
rect("#", 0, MAP_H - 1, MAP_W, 1); // 아래쪽 테두리
rect("#", 0, 0, 1, MAP_H); // 왼쪽 테두리
rect("#", MAP_W - 1, 0, 1, MAP_H); // 오른쪽 테두리

rect("2", 4, 3, 3, 2); // 낮은 블록 덩어리 (점프 연습)
rect("3", 26, 3, 2, 2); // 높은 블록 덩어리
rect("#", 9, 6, 1, 6); // 세로 벽 (점프해도 못 넘음)
rect("2", 12, 14, 2, 2); // 계단 1단 (낮은 블록)
rect("3", 14, 14, 2, 2); // 계단 2단 (높은 블록) — 낮은 블록 위에서 한 번 더 점프
rect("#", 20, 14, 6, 5); // 방 (벽)
rect(".", 21, 15, 4, 3); // 방 내부
rect(".", 22, 18, 2, 1); // 방 입구
rect("2", 4, 18, 5, 1); // 낮은 담장

export const MAP_ROWS = grid.map((row) => row.join(""));
export const MAP_ASCII = MAP_ROWS.join("\n");

export const SPAWN = { x: 5.5 * TILE, y: 12.5 * TILE };

// 범위 밖은 벽으로 취급한다
export function tileAt(tx, ty) {
  if (tx < 0 || ty < 0 || tx >= MAP_W || ty >= MAP_H) return "#";
  return MAP_ROWS[ty][tx];
}

export function tileHeight(tx, ty) {
  return TILE_HEIGHT[tileAt(tx, ty)] ?? 0;
}
