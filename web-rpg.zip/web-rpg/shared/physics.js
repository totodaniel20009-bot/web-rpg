// 이동·점프·충돌 규칙 — 서버(판정)와 브라우저(예측)가 똑같은 코드를 쓴다.
//
// 좌표 규칙
//   x, y : 바닥 위 위치 (쿼터뷰에서 y 가 클수록 화면 아래쪽)
//   z    : 바닥에서의 높이 (점프하면 올라감)
//   화면에는 (x, y - z) 위치에 그려진다.

import { TILE, tileHeight } from "./map.js";

export const SIM_DT = 1 / 60; // 시뮬레이션 한 스텝 (초)
export const PLAYER_RADIUS = 9; // 캐릭터 충돌 반경
export const MOVE_SPEED = 150; // 이동 속도 (월드 단위/초)
export const GRAVITY = 1100;
export const JUMP_VELOCITY = 450; // 점프 최고 높이 ≈ 450² / (2 × 1100) ≈ 92
export const STEP_HEIGHT = 6; // 이 정도 높이 차이는 그냥 걸어 올라간다

export function createPlayer(x, y) {
  return { x, y, z: 0, vz: 0, dir: Math.PI / 2, grounded: true, jumpLatch: false };
}

export function groundHeightAt(x, y) {
  return tileHeight(Math.floor(x / TILE), Math.floor(y / TILE));
}

const clamp = (v, lo, hi) => (v < lo ? lo : v > hi ? hi : v);

// (x, y) 에 높이 z 로 서 있으면 막는 타일과 겹치는가?
export function collides(x, y, z) {
  const r = PLAYER_RADIUS;
  const tx0 = Math.floor((x - r) / TILE);
  const tx1 = Math.floor((x + r) / TILE);
  const ty0 = Math.floor((y - r) / TILE);
  const ty1 = Math.floor((y + r) / TILE);
  for (let ty = ty0; ty <= ty1; ty++) {
    for (let tx = tx0; tx <= tx1; tx++) {
      if (tileHeight(tx, ty) <= z + STEP_HEIGHT) continue; // 이 높이에서는 넘어갈 수 있음
      const cx = clamp(x, tx * TILE, (tx + 1) * TILE);
      const cy = clamp(y, ty * TILE, (ty + 1) * TILE);
      const dx = x - cx;
      const dy = y - cy;
      if (dx * dx + dy * dy < r * r) return true;
    }
  }
  return false;
}

// 블록 모서리 위에서 떨어지면 살짝 겹칠 수 있다 → 바깥으로 밀어낸다
function resolveOverlaps(p) {
  const r = PLAYER_RADIUS;
  for (let iter = 0; iter < 2; iter++) {
    let moved = false;
    const tx0 = Math.floor((p.x - r) / TILE);
    const tx1 = Math.floor((p.x + r) / TILE);
    const ty0 = Math.floor((p.y - r) / TILE);
    const ty1 = Math.floor((p.y + r) / TILE);
    for (let ty = ty0; ty <= ty1; ty++) {
      for (let tx = tx0; tx <= tx1; tx++) {
        if (tileHeight(tx, ty) <= p.z + STEP_HEIGHT) continue;
        const cx = clamp(p.x, tx * TILE, (tx + 1) * TILE);
        const cy = clamp(p.y, ty * TILE, (ty + 1) * TILE);
        const dx = p.x - cx;
        const dy = p.y - cy;
        const d2 = dx * dx + dy * dy;
        if (d2 >= r * r || d2 === 0) continue;
        const k = (r - Math.sqrt(d2)) / Math.sqrt(d2);
        p.x += dx * k;
        p.y += dy * k;
        moved = true;
      }
    }
    if (!moved) break;
  }
}

// 플레이어 한 명을 dt 초만큼 진행시킨다.
// input = { mx, my, jump }  (mx, my 는 -1..1, jump 는 누르고 있는지 여부)
export function stepPlayer(p, input, dt = SIM_DT) {
  let mx = Number(input.mx) || 0;
  let my = Number(input.my) || 0;
  const len = Math.hypot(mx, my);
  if (len > 1) {
    mx /= len;
    my /= len;
  }
  if (len > 0.01) p.dir = Math.atan2(my, mx);

  // 가로/세로를 따로 움직여서 벽에 닿아도 미끄러지게 한다
  const nx = p.x + mx * MOVE_SPEED * dt;
  if (!collides(nx, p.y, p.z)) p.x = nx;
  const ny = p.y + my * MOVE_SPEED * dt;
  if (!collides(p.x, ny, p.z)) p.y = ny;
  resolveOverlaps(p);

  // 점프: 바닥에 있을 때 누르면 뜬다. 키를 떼야 다시 뛸 수 있다.
  if (input.jump) {
    if (p.grounded && !p.jumpLatch) {
      p.vz = JUMP_VELOCITY;
      p.grounded = false;
      p.jumpLatch = true;
    }
  } else {
    p.jumpLatch = false;
  }

  // 높이 처리
  const gz = groundHeightAt(p.x, p.y);
  if (p.grounded) {
    if (gz > p.z) p.z = gz; // 낮은 단차는 그냥 오른다
    else if (gz < p.z - 0.01) {
      p.grounded = false; // 블록 가장자리를 벗어났다 → 떨어진다
      p.vz = 0;
    }
  }
  if (!p.grounded) {
    p.vz -= GRAVITY * dt;
    p.z += p.vz * dt;
    if (p.vz <= 0 && p.z <= gz) {
      p.z = gz;
      p.vz = 0;
      p.grounded = true;
    }
  }
  return p;
}
